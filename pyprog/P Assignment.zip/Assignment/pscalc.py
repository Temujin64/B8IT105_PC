def otratecalc():
	#Calculates the overtime rate by multiplying the hourly rate and overtime multiplier
	otrate = hourrate * otmul
	return otrate
	
def totnormcalc():
	#Total pay for normal hours
	normaltotal = normhours * hourrate
	return normaltotal
	
def tototcalc():
	#Total pay for overtime hours
	ottotal = othours * otrate
	return ottotal
	
def grosscalc():
	#Gross income
	gross = normaltotal + ottotal
	return gross
	
def totdedcalc():
	#Total deductions
	deductions = gross * taxrate
	return deductions
	
def netcalc():
	#Net pay
	net = gross - deductions
	return net