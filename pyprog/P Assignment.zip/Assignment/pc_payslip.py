import string
import psval2

		
#pc_payslip.py
#This program takes info from the user and ouputs a payslip.

###Input & validation section###

#employee name entry and validation
empanme = psval2.empnameval()

#employee number entry and validation
empno = psval2.empnoval()

#week ending entry and validation
endweek = psval2.endweekval()

#hours worked entry and validation
emphours = psval2.emphoursval()

#hourly rate entry and validation
hourrate = psval2.hourrateval()

#over time multiplier and validation
otmul = psval2.otmulval()

#tax rate entry and validation
taxrate = psval2.taxrateval()

import pscalc

###calculation section###

#Sets overtime hours to 0 if overtime cutoff has not been met
if emphours <= 37.5:
	normhours = emphours
	othours = 0

#Sets normal hours to 37.5 and overtime to the remainder of overall hours divided by overtime cutoff
else:
	normhours = 37.5
	othours = emphours%37.5

pscalc.otratecalc()
pscalc.totnormcalc()
pscalc.tototcalc()
pscalc.grosscalc()
pscalc.totdedcalc()
pscalc.netcalc()


###Layout###

#Assigns a variable to the title and subtitle
title = "P A Y S L I P "
subtitle = "WEEK ENDING "+endweek

#Assigns an integer to the subtitle width for string formatting.
#This assures us that the subtitle will always start 1 character in from the longest line beneath it.
#This way the print out is more likely to look centred no matter the length of the user inputs.
#33 is a fixed number which is based on the legnth of fixed text that doesn't change, such as the titles themselves and "Employee: " etc.
if len(empanme) > len(empno):
	stw = 33 + len(empanme)
else:
	stw = 33 + len(empno)

#In order to appear as though it is in the middle of as well as above the subtitle, the width needs to be reduced by 3.	
tw = stw - 3

#Sets the amount of spaces needed between earnings and deductions
#The length of empname or empno are used to allow the length of the payslip to be dependent on the length of either of these variables.
#30 is based off constant strings and their lenghts
if len(empanme) > len(empno):
	dedw = 30 + len(empanme)
else:
	dedw = 30 + len(empno)

#Similar to the previous if statement, ensures there's a balance regardless of the length of the user inputs.
#23 is based off constant strings and their lenghts
if len(empanme) > len(empno):
	hoursw = 23 + len(empanme)
else:
	hoursw = 23 + len(empno)

#Width for the row with normal hour calculations.
#Subtracting by 32 ensures that the integers are alligned with the headers above.
normintw = hoursw - 32

#Same for above but allows for the differening lentghts of text within.
if len(empanme) > len(empno):
	otintw = 13 - len(empanme)
else:
	otintw = 13 - len(empno)

#Tax represented as whole number string
taxstr = "Tax @ " + str(float((taxrate*100))) + "%"

#This width ensures that the string assigned to the variable taxstr appears directly below "Deductions"
dedintw = dedw - 31

#Determines the number of spaces from the right the the total deductions figure must be in order to maintain the title in the centre.
if len(empanme) > len(empno):
	dtotw = 5 + len(empanme)
else:
	dtotw = 5 + len(empno)

	
if othours >= 10:
	otw = 1
else:
	otw = 2

dedtotalw = dedw - 13
dedtotintw  = dedw - 32	

print "%*s" % (tw, title)
print "%*s" % (stw, subtitle)
print "Employee:", empanme
print "Number:", empno
print
print "Earnings %*s" % (dedw, "Deductions")
print
print "                  Hours Rate  Total"
print "Hours (normal)    %0.2f %0.2f %0.2f %*s %*s %0.2f" % (normhours, hourrate, normaltotal, dedintw, taxstr, dtotw, "", deductions)
print "Hours (overtime)%*s% 0.2f %0.2f %0.2f" % (otw, "", othours, otrate, ottotal)
print
print "Total Pay: %*s Total Deductions %*s %0.2f" % (dedtotalw, gross, dedtotintw, "", deductions)




















