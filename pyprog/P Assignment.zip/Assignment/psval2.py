import string

def endweekval():							#The function being used to validate endweek

	invalid = 1								# Set invalid to 1 so loop executes

	while invalid == 1:
		invalid = 0							# Assume validation passes
		
		print
		print "END OF WEEK. Must be in the dd/mm/yyyy format."
		endweek = raw_input("Please enter the date for the end of the week: ")
			
		endweek = string.replace(endweek, " ", "") 		# Removes spaces
		endweek = string.replace(endweek, chr(9), "")	# Removes tabs

		
	# Validate that the string only contains "0"-"9"or "/"

		if string.count(endweek,"/") != 2:
			print "Must have two slashes."
			invalid = 1
		
		
		for ch in endweek:
			if (ord(ch) < 47 or ord(ch) >59):
				invalid = 1
				print "Invalid character : ",ch

	# Now check the others

		if invalid != 1:
			dd,mm,yyyy = string.split(endweek, "/")
			idd, imm, iyyyy = int(dd), int(mm), int(yyyy)
			
			if len(endweek) != 10:
				print "Wrong length - 10 chars only."
				invalid = 1
			elif string.count(endweek,"/") != 2:
				print "Must have two slashes."
				invalid = 1
			#elif imm < 1 or imm > 12:
			#	print "Invalid month (1-12)"
			#	invalid = 1
			elif idd <1 or idd > 31:
				print "Invalid day (1-31)."
				invalid = 1
	return endweek
	
def empnameval():							#The function being used to validate empname

	invalid = 1								# Set invalid to 1 so loop executes

	while invalid == 1:
		invalid = 0							# Assume validation passes
		
		print
		print "EMPLOYEE NAME:Use a maximum of 35 characters, upper and lower case alphabet only."
		empname = raw_input("Please enter the employee's name: ")
			
		empname = string.replace(empname, chr(9), " ")	# Replaces tabs with spaces
		
		if len(empname) > 35:
			print "Wrong length - fewer than 35 chars only."
			invalid = 1

		
	# Validate that the string only contains "A"-"Z" and "a"-"z"
		
		for ch in empname:
			if (ord(ch) < 65 or ord(ch) >90) and (ord(ch) < 97 or ord(ch) >122) and ord(ch) != 32:
				invalid = 1
				print "Invalid character : ",ch

	return empname
	
def empnoval():							#The function being used to validate empno

	invalid = 1								# Set invalid to 1 so loop executes

	while invalid == 1:
		invalid = 0							# Assume validation passes

		print
		print "EMPLOYEE NUMBER: Must contain alphanumeric values only, i.e. no symbols"
		empno = raw_input("Please enter the employee number: ")
			
		empno = string.replace(empno, chr(9), " ")	# Removes tabs
		
		if len(empno) > 10:
			print "Too - must have fewer than 10 chars."
			invalid = 1
		
	# Validate that the string only contains "1"-"9" and "a"-"z"
		
		for ch in empno:
			if (ord(ch) < 65 or ord(ch) >90) and (ord(ch) < 97 or ord(ch) >122) and (ord(ch) < 48 or ord(ch) >57):
				invalid = 1
				print "Invalid character : ",ch

	return empno

def emphoursval():							#The function being used to validate emphours

	invalid = 1								# Set invalid to 1 so loop executes

	while invalid == 1:
		invalid = 0							# Assume validation passes

		print
		print "HOURS WORKED: Maximum of 60 hours"
		emphours = raw_input("Please insert the number of hours the employee has worked: ")

	# Validate that the string only contains "1"-"9" and "."
		
		for ch in emphours:
			if (ord(ch) < 48 or ord(ch) >57) and ord(ch) != 46:
				invalid = 1
				print "Invalid character : ",ch
	
		if invalid == 0:
			emphours = float(emphours)
			
		if emphours< 0 or emphours > 60.0:
			print "Incorrect number of hours - must be fewer than 60 hours."
			invalid = 1

	return emphours
	
def hourrateval():							#The function being used to validate hourrate

	invalid = 1								# Set invalid to 1 so loop executes

	while invalid == 1:
		invalid = 0							# Assume validation passes

		print
		print "HOURLY RATE: Must not exceed 50"
		hourrate = raw_input("Please insert the hourly rate: ")

		
	# Validate that the string only contains "1"-"9" and "."
		
		for ch in hourrate:
			if (ord(ch) < 48 or ord(ch) >57) and ord(ch) != 46:
				invalid = 1
				print "Invalid character : ",ch
	
		if invalid == 0:
			hourrate = float(hourrate)
			
		if hourrate > 50.00:
			print "Hourly rate too high - must be less than 50.00."
			invalid = 1

	return hourrate

def otmulval():								#The function being used to validate the overtime multiplier

	invalid = 1								# Set invalid to 1 so loop executes

	while invalid == 1:
		invalid = 0							# Assume validation passes

		print
		print "OVERTIME MULTIPLIER: Cannot be less than 0 or greater than 3"
		otmul = raw_input("Please insert the overtime multiplier: ")

		
	# Validate that the string only contains "1"-"9" and "."
		
		for ch in otmul:
			if (ord(ch) < 48 or ord(ch) >57) and ord(ch) != 46:
				invalid = 1
				print "Invalid character : ",ch
	
		if invalid == 0:
			otmul = float(otmul)
			
		if otmul < 0 or otmul > 3.0:
			print "Incorrect overtime multiplier - must be between 0 and 3.0."
			invalid = 1

	return otmul
	
def taxrateval():							#The function being used to validate taxrate

	invalid = 1								# Set invalid to 1 so loop executes

	while invalid == 1:
		invalid = 0							# Assume validation passes

		print
		print "TAX RATE: Must be either 10, 17.5 or 20"
		taxrate = raw_input("Please insert a tax rate: ")

	# Validate that the string only contains "1"-"9" and "."
		
		for ch in taxrate:
			if (ord(ch) < 48 or ord(ch) >57) and ord(ch) != 46:
				invalid = 1
				print "Invalid character : ",ch
	
		if invalid == 0:
			taxrate = float(taxrate)
			
		if (taxrate < 10.0 or taxrate > 10.0) and (taxrate < 17.5 or taxrate > 17.5) and (taxrate < 20.0 or taxrate > 20.0):
			print "Incorrect tax rate, must be either 10, 17.5 or 20."
			invalid = 1
		
		taxrate=taxrate/100

	return taxrate