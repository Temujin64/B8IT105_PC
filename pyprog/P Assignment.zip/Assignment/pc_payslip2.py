import string
import psval

#pc_payslip.py
#This program takes info from the user and ouputs a payslip.

###Input & validation section###

#employee name entry and validation
empanme = psval.empnameval()

#employee number entry and validation
empno = psval.empnoval()

#week ending entry and validation
endweek = psval.endweekval()

#hours worked entry and validation
emphours = psval.emphoursval()

#hourly rate entry and validation
hourrate = psval.hourrateval()

#over time multiplier and validation
otmul = psval.otmulval()

#tax rate entry and validation
taxrate = psval.taxrateval()


###calculation section###

#Sets overtime hours to 0 if overtime cutoff has not been met
if emphours <= 37.5:
	normhours = emphours
	othours = 0

#Sets normal hours to 37.5 and overtime to the remainder of overall hours divided by overtime cutoff
else:
	normhours = 37.5
	othours = emphours%37.5

#Calculates the overtime rate by multiplying the hourly rate and overtime multiplier
otrate = hourrate * otmul

#Total pay for normal hours
normaltotal = normhours * hourrate

#Total pay for overtime hours
ottotal = othours * otrate

#Gross income
gross = normaltotal + ottotal

#Total deductions
deductions = gross * taxrate

#Net pay
net = gross - deductions


###Layout###

#Assigns a variable to the title and subtitle
title = "P A Y S L I P "
subtitle = "WEEK ENDING "+endweek

#Tax represented as whole number string
taxstr = "Tax @ " + str(float((taxrate*100))) + "%"



#Esnures the overtime row is aligned in the column regardless of how many hours are worked.
if othours >= 10:
	otw = 1
else:
	otw = 2

#Makes sure the deductions column is alligned even when there is a 4 figure number.
if deductions >=1000:
	fourfigw = 1
else:
	fourfigw = 0
	
if gross >=1000:
	grossw = 0
	dedw = 1

else:
	grossw = 1
	dedw = 0	


print "%45s" % (title)
print "%48s" % (subtitle)
print "Employee:", empanme
print "Number:  ", empno
print
print "Earnings                    %*s             Deductions" % (fourfigw, "")
print
print "                  Hours Rate %*s Total" % (fourfigw, "")
print "Hours (normal)    %0.2f %0.2f%*s %0.2f     %s           %0.2f" % (normhours, hourrate, fourfigw, "", normaltotal, taxstr, deductions)
print "Hours (overtime)%*s% 0.2f %0.2f %0.2f" % (otw, "", othours, otrate, ottotal)
print
print "Total Pay:      %*s              %0.2f    %*s Total Deductions      %0.2f" % (grossw, "", gross, dedw, "", deductions)
print "%*s %*s                                         Net Pay               %0.2f" % (fourfigw, "", dedw, "", net)




















